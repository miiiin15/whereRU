# GmoneyTrans Japan Android - 프로젝트 가이드라인

일본향 해외송금 앱. Multi-module Android, Kotlin + Jetpack Compose (Fragment 호스팅).
화면 코드명은 CT + 3자리 숫자 체계 (예: CT001, CT005, CT010).

## DO NOT
- `local.properties`의 secrets를 커밋하지 않는다.
- 기존 공통 컴포저블로 해결 가능할 때 새 컴포저블을 만들지 않는다.
- 직접 `Dialog`, `ProgressBar`, `BasicTextField`를 새로 만들지 않는다.
- **텍스트 입력이 필요하면 `BasicTextField`가 아닌 `MultipleFilledTextInput`을 사용한다.** 이메일+도메인 입력은 `InputEmailSelectDomainForm`, 전화번호는 `MultipleFilledTextInput` + `PhoneNumberVisualTransformation`을 사용한다. 드롭다운 선택은 `MultipleFilledSelectInput`을 사용한다. (상세: [UI 커스텀 컴포저블](UI_COMPOSABLES.md) → Text Input 계층 참조)
- 아이콘, 이미지 파일을 직접 생성하지 않는다.
- `any` 타입이나 unchecked cast를 남용하지 않는다.

## 공통 명령어
- `./gradlew assembleDevDebug` — Dev Debug APK 빌드
- `./gradlew assembleDevStaging` — Dev Staging APK 빌드 (외부 배포용)
- `./gradlew assembleLiveRelease` — Live Release APK 빌드
- `./gradlew :feature:auth:compileDevDebugKotlin` — auth 모듈 컴파일 확인
- `./gradlew kspDevDebugKotlin` — Hilt/KSP 코드 생성

## 가이드 (상세 문서)

### 규칙 계열
- [프로젝트 구조](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/규칙/CLAUDE(프로젝트 공통 구조).md) — 기술 스택, 모듈 구조, 디렉터리 레이아웃

### 스킬 계열
- [스타일 가이드](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - STYLE_GUIDE.md) — TextSize 매핑, 색상, 여백 기준값 (HTML 스펙 ↔ Android 대응)
- [네트워크 & 비동기 흐름](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - Network_Async_Flow.md) — API 호출 파이프라인, toApiServiceResult → unwrapApiServiceResult → collectDataResource, 비즈니스 에러 분기 (return_code != "100" → onError)
- [코딩 표준 & 아키텍처](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - coding-standards.md) — MVVM+MVI, BaseViewModel, Repository, Screen 3단 구조, DI, Network, Security, 코딩 스타일, UI 재사용 규칙
- [UI 화면 인프라](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - UI Screen Infrastructure Guide.md) — BaseFragment, BaseRoute, TitleBar, Alert, Loading, Snackbar
- [UI 커스텀 컴포저블](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill -Ui Custom Composables Guide.md) — Button, Input, ButtonContainer, OTP 등 공통 컴포저블 API
- [Composable 생성 가이드](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - Composable_Creation.md) — core:ui vs feature 모듈 배치 판단 기준
- [SessionStore 가이드](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - SessionStore.md) — 화면 간 플로우 데이터 공유 (FirstSignUpSessionStore 등)
- [Navigation 가이드](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/스킬/Skill - Navigation.md) — AppDestination, DestinationMapper, nav_main.xml 등록 패턴

### 서비스/프로젝트 계열
- [회원가입 개편 — 작업 규칙](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/서비스/프로젝트/회원가입/작업/로직/RULES - SignUp.md) — signupv2 패키지 규칙, UI 금지사항, 진행 상태
- [회원가입 개편 — 공통 수정사항](/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/서비스/프로젝트/회원가입/작업/로직/SignUp - COMMON.md) — UI 사이즈, Annotation 체계
- 회원가입 개편 — 화면별 작업 스펙: `/Users/mintae/Documents/Obsidian/GmoneyTrans_Japan_app_plan/Android/서비스/프로젝트/회원가입/작업/UI/CT{번호}.md`
